# Weather App — Android

A clean, glass-style weather app for Android, built with a WebView wrapping our HTML/CSS/JS weather UI.

## Requirements

- **Android Studio** (Hedgehog 2023.1 or newer) — free download at https://developer.android.com/studio
- **Android SDK** (API 24+, installed via Android Studio)
- A physical Android device **or** Android Emulator

## How to Build & Install

### Option A — Android Studio (recommended)

1. Open Android Studio
2. Click **File → Open** and select this `WeatherApp` folder
3. Wait for Gradle to sync (bottom progress bar)
4. Click the green **▶ Run** button (or press Shift+F10)
5. Choose your device/emulator — the app installs and launches automatically

### Option B — Command Line

```bash
cd WeatherApp
./gradlew assembleDebug
# APK will be at: app/build/outputs/apk/debug/app-debug.apk
```

Then install via ADB:
```bash
adb install app/build/outputs/apk/debug/app-debug.apk
```

## How it works

The app is a thin Android WebView wrapper around `app/src/main/assets/weather.html`.  
All weather data comes from the free [Open-Meteo API](https://open-meteo.com/) — no API key needed.

## Customisation

- To change the default city, open `assets/weather.html` and edit the `lat`, `lon`, `city` variables near the bottom of the `<script>` tag.
- To change the app name, edit `res/values/strings.xml`.
- To swap the icon, replace `res/drawable/ic_launcher.png` with your own image (192×192px recommended).

## Permissions

- `INTERNET` — required to fetch weather data from Open-Meteo
